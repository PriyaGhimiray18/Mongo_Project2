'use client';
import { useEffect, useState } from 'react';
import Footer from '../component/footer'; 
import RoomCard from '../component/RoomCard';
import '@/styles/style.css';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function Home() {
  const [newHostels, setNewHostels] = useState([]);

  const hardcodedHostelNames = [
    'Hostel A',
    'Hostel B',
    'Hostel RKA',
    'Hostel RKB',
    'Hostel NK',
    'Hostel E',
    'Hostel Lhawang',
    'Hostel F',
    'Hostel C',
    'Hostel D'
  ];

  useEffect(() => {
  const fetchNewHostels = async () => {
    try {
      const res = await fetch('/api/hostels');
      const data = await res.json();

      // Normalize function: remove "Hostel " and lowercase
      const normalize = (name) =>
        name.replace(/^Hostel\s+/i, '').toLowerCase().trim();

      const normalizedHardcoded = hardcodedHostelNames.map(normalize);

      const filtered = data.hostels.filter((h) => {
        const normalizedDbName = normalize(h.name);
        return !normalizedHardcoded.includes(normalizedDbName);
      });

      setNewHostels(filtered);
    } catch (err) {
      console.error('Error fetching hostels:', err);
    }
  };

  fetchNewHostels();
}, []);

  return (
    <div>
      <section id="rooms" className="container my-5">
        <h2 className="text-center mb-5">Available Hostel</h2>

        {/* Boy's Hostels */}
        <h3 className="text-dark mb-4">Boy's Hostels</h3>
        <div className="row">
          <RoomCard hostel="Hostel A" image="/img/hostelA.jpg" description="Boy's Hostel" accommodation="Two people per room" link="/available-room?hostel=HostelA" />
          <RoomCard hostel="Hostel B" image="/img/hb.jpg" description="Boy's Hostel" accommodation="Two people per room" link="/available-room?hostel=HostelB" />
          <RoomCard hostel="Hostel RKA" image="/img/RKA.jpg" description="Boy's Hostel" accommodation="Four people per room" link="/available-room?hostel=HostelRKA" />
          <RoomCard hostel="Hostel RKB" image="/img/RKB.jpg" description="Boy's Hostel" accommodation="Four people per room" link="/available-room?hostel=HostelRKB" />
          <RoomCard hostel="Hostel NK" image="/img/nk.jpg" description="Boy's Hostel" accommodation="Four people per room" link="/available-room?hostel=HostelNK" />
          <RoomCard hostel="Hostel E" image="/img/he.jpg" description="Boy's Hostel" accommodation="Two people per room" link="/available-room?hostel=HostelE" />
          <RoomCard hostel="Hostel Lhawang" image="/img/lhawang.jpg" description="Boy's Hostel" accommodation="Four people per room" location="Near Aurora Nursing College" link="/available-room?hostel=HostelLhawang" />
        </div>

        {/* Girl's Hostels */}
        <h3 className="text-dark mt-5 mb-4">Girl's Hostels</h3>
        <div className="row">
          <RoomCard hostel="Hostel F" image="/img/hf.jpg" description="Girl's Hostel" accommodation="Three people per room" link="/available-room?hostel=HostelF" />
          <RoomCard hostel="Hostel C" image="/img/hc.jpg" description="Girl's Hostel" accommodation="Two people in a room" link="/available-room?hostel=HostelC" />
          <RoomCard hostel="Hostel D" image="/img/hd.jpg" description="Girl's Hostel" accommodation="Two people in a room" link="/available-room?hostel=HostelD" />
        </div>

        {/* Dynamically Fetched New Hostels */}
        {newHostels.length > 0 && (
          <>
            <h3 className="text-dark mt-5 mb-4">Newly Added Hostels</h3>
            <div className="row">
              {newHostels.map((hostel) => (
                <RoomCard
                  key={hostel.id}
                  hostel={hostel.name}
                  image="/img/default.jpg" // Or generate based on name if needed
                  description={hostel.description || 'No description'}
                  accommodation={hostel.accommodation || 'Info not available'}
                  link={`/available-room?hostel=${encodeURIComponent(hostel.name)}`}
                />
              ))}
            </div>
          </>
        )}
      </section>
      <Footer />
    </div>
  );
}
