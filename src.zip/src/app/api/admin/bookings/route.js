import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';  // make sure prisma is default export

export async function GET() {
  try {
    const bookings = await prisma.booking.findMany({
      include: {
        user: {
          select: {
            username: true,
            email: true,
          },
        },
        room: {
          select: {
            roomNumber: true,
            hostel: {
              select: {
                name: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    const formattedBookings = bookings.map(booking => ({
      id: booking.id,
      studentName: booking.studentName,
      studentID: booking.studentId,
      department: booking.department,
      email: booking.email,
      phone: booking.phone,
      hostelName: booking.room.hostel.name,
      roomNumber: booking.room.roomNumber.toString(),
      checkinDate: booking.checkinDate,
      numPeople: booking.numPeople,
      status: booking.status,
    }));

    return NextResponse.json(formattedBookings);
  } catch (error) {
    console.error('Error fetching bookings:', error);
    return NextResponse.json(
      { error: 'Failed to fetch bookings' },
      { status: 500 }
    );
  }
}
