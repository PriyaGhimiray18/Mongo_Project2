'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import '@/styles/style.css';

export default function RoomBookingForm() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    hostelName: '',
    checkinDate: '',
    numPeople: '',
    studentName: '',
    studentID: '',
    department: '',
    roomNumber: '',
    email: '',
    phone: ''
  });

  const [roomInfo, setRoomInfo] = useState(null);
  const [error, setError] = useState('');
  const [submitStatus, setSubmitStatus] = useState('');

  // Check authentication and get user data from session storage
  useEffect(() => {
    const userData = sessionStorage.getItem('user');
    if (!userData) {
      router.push('/');
    } else {
      const parsedUser = JSON.parse(userData);
      setUser(parsedUser);
      setFormData(prev => ({
        ...prev,
        studentName: parsedUser.username || '',
        studentID: parsedUser.studentId || '',
        email: parsedUser.email || ''
      }));
    }
  }, [router]);

  // Fetch room information when hostel and room number are selected
  useEffect(() => {
    if (formData.hostelName && formData.roomNumber) {
      fetch(`/api/rooms?hostel=${encodeURIComponent(formData.hostelName)}`)
        .then(res => res.json())
        .then(data => {
          const room = data.rooms?.find(r => r.roomNumber === parseInt(formData.roomNumber));
          if (room) {
            setRoomInfo(room);
            setError('');
          } else {
            setRoomInfo(null);
            setError('Room not found');
          }
        })
        .catch(err => {
          console.error('Error fetching room info:', err);
          setRoomInfo(null);
          setError('Failed to fetch room information');
        });
    } else {
      setRoomInfo(null);
      setError('');
    }
  }, [formData.hostelName, formData.roomNumber]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'numPeople') {
      const maxPeople = roomInfo?.capacity || 5;
      let newValue = value;

      // Clamp value to max capacity and min 1
      if (parseInt(newValue) > maxPeople) {
        newValue = maxPeople.toString();
      }
      if (parseInt(newValue) < 1 || isNaN(parseInt(newValue))) {
        newValue = '1';
      }

      setFormData(prevData => ({
        ...prevData,
        [name]: newValue
      }));
      setError('');
      setSubmitStatus('');
      return;
    }

    if (name === 'hostelName') {
      setFormData(prevData => ({
        ...prevData,
        [name]: value.trim()
      }));
    } else {
      setFormData(prevData => ({
        ...prevData,
        [name]: value
      }));
    }

    setError('');
    setSubmitStatus('');
  };

  const validateForm = async (e) => {
    e.preventDefault();
    
    if (!user) {
      setError('Please log in to make a booking');
      router.push('/');
      return;
    }

    // Validate room capacity
    if (roomInfo && parseInt(formData.numPeople) > roomInfo.capacity) {
      setError(`This room has a maximum capacity of ${roomInfo.capacity} people`);
      return;
    }

    if (roomInfo && roomInfo.status === 'FULLY_BOOKED') {
      setError('This room is fully booked');
      return;
    }

    if (roomInfo && (roomInfo.occupants + parseInt(formData.numPeople)) > roomInfo.capacity) {
      setError(`Only ${roomInfo.capacity - roomInfo.occupants} spaces available in this room`);
      return;
    }

    try {
      setError('');
      setSubmitStatus('submitting');

      // Submit booking to the API
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          hostelName: formData.hostelName,
          roomNumber: parseInt(formData.roomNumber),
          studentName: formData.studentName,
          studentId: formData.studentID,
          department: formData.department,
          checkinDate: new Date(formData.checkinDate).toISOString(),
          numPeople: parseInt(formData.numPeople),
          email: formData.email,
          phone: formData.phone,
          userId: user.id // Use the session user ID
        }),
      });

      const data = await response.json();
      console.log('Response data:', data);

      if (!response.ok) {
        throw new Error(data.error || data.details || 'Failed to submit booking');
      }

      // Clear form and show success message
      setFormData({
        hostelName: '',
        checkinDate: '',
        numPeople: '',
        studentName: '',
        studentID: '',
        department: '',
        roomNumber: '',
        email: '',
        phone: ''
      });
      setSubmitStatus('success');
      setError('');

      // Update room info with the returned data
      if (data.room) {
        setRoomInfo({
          ...data.room,
          availableSpaces: data.room.capacity - data.room.occupants
        });
      }
    } catch (error) {
      console.error('Error submitting booking:', error);
      setError(error.message);
      setSubmitStatus('error');
    }
  };

  // Helper function to get button color based on room status
  const getButtonStyle = () => {
    if (!roomInfo) return 'btn-primary';
    
    switch (roomInfo.status) {
      case 'FULLY_BOOKED':
        return 'btn-danger';
      case 'PARTIALLY_BOOKED':
        return 'btn-warning';
      default:
        return 'btn-primary';
    }
  };

  if (user === null) {
    return <div className="text-center mt-5">Loading...</div>;
  }

  if (!user) {
    return <div className="text-center mt-5">Please log in to make a booking.</div>;
  }

  return (
    <section className="container my-5">
      <h2 className="text-center mb-4">Room Booking Form</h2>
      <div className="row justify-content-center">
        <div className="col-md-8">
          <form onSubmit={validateForm}>
            <div className="mb-4">
              <label htmlFor="hostelName" className="form-label fw-bold">Select Hostel</label>
              <select
                className="form-select"
                id="hostelName"
                name="hostelName"
                value={formData.hostelName}
                onChange={handleChange}
                required
              >
                <option value="" disabled>Choose a hostel</option>
                <option value="Hostel A">Hostel A</option>
                <option value="Hostel B">Hostel B</option>
                <option value="RKA">RKA</option>
                <option value="RKB">RKB</option>
                <option value="NK">NK</option>
                <option value="Lhawang">Lhawang</option>
                <option value="Hostel E">Hostel E</option>
                <option value="Hostel C">Hostel C</option>
                <option value="Hostel D">Hostel D</option>
                <option value="Hostel F">Hostel F</option>
              </select>
            </div>

            <div className="row mb-4">
              <div className="col-md-6">
                <label htmlFor="checkinDate" className="form-label fw-bold">Date of Booking</label>
                <input
                  type="date"
                  className="form-control"
                  id="checkinDate"
                  name="checkinDate"
                  value={formData.checkinDate}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="col-md-6">
                <label htmlFor="numPeople" className="form-label fw-bold">
                  No. of People
                  {roomInfo && (
                    <span className="text-muted ms-2">
                      (Max: {roomInfo.capacity}, Available: {roomInfo.capacity - roomInfo.occupants})
                    </span>
                  )}
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="numPeople"
                  name="numPeople"
                  min="1"
                  max={roomInfo?.capacity || 5}
                  value={formData.numPeople}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="card mb-4 p-3">
              <h5 className="mb-3">Student Details</h5>
              <div className="row g-3">
                <div className="col-md-12 mb-3">
                  <label htmlFor="studentName" className="form-label">Name(s)</label>
                  <textarea
                    className="form-control"
                    id="studentName"
                    name="studentName"
                    rows="3"
                    placeholder="One name per line"
                    value={formData.studentName}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-12 mb-3">
                  <label htmlFor="studentID" className="form-label">Student ID(s)</label>
                  <textarea
                    className="form-control"
                    id="studentID"
                    name="studentID"
                    rows="3"
                    placeholder="One ID per line"
                    value={formData.studentID}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="col-md-12 mb-3">
                  <label htmlFor="department" className="form-label">Department(s)</label>
                  <textarea
                    className="form-control"
                    id="department"
                    name="department"
                    rows="3"
                    placeholder="One department per line"
                    value={formData.department}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="row mb-4">
              <div className="col-md-6">
                <label htmlFor="roomNumber" className="form-label fw-bold">Room No.</label>
                <input
                  type="number"
                  className="form-control"
                  id="roomNumber"
                  name="roomNumber"
                  value={formData.roomNumber}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="col-md-6">
                <label htmlFor="phone" className="form-label fw-bold">Phone Number</label>
                <input
                  type="tel"
                  className="form-control"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="mb-4">
              <label htmlFor="email" className="form-label fw-bold">Email</label>
              <input
                type="email"
                className="form-control"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>

            {error && (
              <div className="alert alert-danger" role="alert">
                {error}
              </div>
            )}

            {submitStatus === 'success' && (
              <div className="alert alert-success" role="alert">
                Booking successful!
              </div>
            )}

            <button
              type="submit"
              className={`btn ${getButtonStyle()} w-100`}
              disabled={submitStatus === 'submitting'}
            >
              {submitStatus === 'submitting' ? 'Booking...' : 'Book Now'}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
