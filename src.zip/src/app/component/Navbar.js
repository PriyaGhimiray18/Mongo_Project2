'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

export default function Navbar() {
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) return null; // Avoid rendering on server

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link href="/" className="navbar-brand d-flex align-items-center">
          <Image
            src="/img/logo.jpg"
            alt="Hostel Logo"
            width={40}
            height={40}
            style={{ marginRight: '10px' }}
          />
          Hostel Booking
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link href="/home" className="nav-link">Home</Link>
            </li>
            <li className="nav-item">
              <Link href="/hostel" className="nav-link">Hostel</Link>
            </li>
            <li className="nav-item">
              <Link href="/booking" className="nav-link">Booking</Link>
            </li>
            <li className="nav-item">
              <Link href="/contact" className="nav-link active">Contact</Link>
            </li>
            <li className="nav-item">
              <Link href="/dashboard" className="nav-link">Dashboard</Link>
            </li>
          </ul>

          <div className="d-flex">
            <input
              className="form-control me-2"
              type="search"
              placeholder="Search"
              aria-label="Search"
            />
            <button className="btn btn-secondary" type="submit">
              Search
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
